public interface MyList<E> {
    boolean add(E element);
    E get(int index);
    E remove(int index);
    int size();
    // Other methods specified by the List interface
}

